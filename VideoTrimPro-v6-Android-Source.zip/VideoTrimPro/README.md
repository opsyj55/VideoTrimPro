# VideoTrim Pro — V6 (UI/UX overhaul)

## New in V6
**Editing flow**
- One timeline for everything. A **Keep selection / Remove selection** toggle replaces the old
  "type the seconds" middle-section form. In Remove mode the area that will be cut turns red.
- Timeline now has a **playhead** (touch anywhere that isn't a handle to scrub), larger handles
  with grips that don't "jump" to your finger, haptic feedback, and centre-cropped thumbnails.
- **Use playhead** buttons set IN/OUT precisely (also a non-drag alternative for accessibility).
- Preview matches the export: Keep mode stops at OUT, Remove mode skips over the cut.
- Custom play/pause button and time readout; tap the video to play/pause.

**Export**
- Sticky Export button that is always reachable; the label changes with the mode.
- Quality is now an obvious chip row that applies to both modes.
- Real **progress bar + Cancel** during export.
- After saving: **Share** and **Play** buttons.

**Polish & fixes**
- Empty state with a clear "Choose video" call to action.
- Proper edge-to-edge handling (required by targetSdk 35 / Android 15).
- Thumbnails are extracted on a background thread and downscaled (previously full-resolution
  frames on the main thread, which could freeze or run out of memory on 4K clips).
- Saving works on Android 9 and below (RELATIVE_PATH/IS_PENDING don't exist there).
- Layouts moved to XML, strings to strings.xml, colours to colors.xml.
- Rotation no longer restarts the activity; state is also saved for process death.

## Existing features carried forward
- System video picker, in-app preview, Media3 Transformer export (original / 1080p / 720p / 480p).
- Saves MP4 to Movies/VideoTrim Pro.
- AdMob banner using Google's test unit.
- GitHub Actions workflow for a debug APK.

## Build
Android Studio (JDK 17, SDK 35), or push to GitHub and run **Actions → Build VideoTrim Pro APK**.

## Important testing notes
This is development source, not a compiled, signed, or device-verified release. Test on a physical
device: trimming, remove-section joins, audio/video sync, rotation, 4K and large files, each
quality option, and (if you can) an Android 9 or older device for the save path.
Replace Google's sample AdMob IDs, add consent/privacy handling, a privacy policy, and a signed
release config before Play Store publication.
