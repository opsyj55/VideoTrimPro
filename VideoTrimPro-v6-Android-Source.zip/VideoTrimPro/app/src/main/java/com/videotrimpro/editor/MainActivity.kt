package com.videotrimpro.editor

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.transformer.Effects
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.chip.ChipGroup
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.snackbar.Snackbar
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

@UnstableApi
class MainActivity : AppCompatActivity() {

    companion object {
        private const val THUMB_COUNT = 10
        private const val THUMB_HEIGHT_PX = 160
        private const val MIN_PART_MS = 200L
        private const val END_EPSILON_MS = 50L
        private const val KEY_URI = "video_uri"
        private const val KEY_START = "range_start"
        private const val KEY_END = "range_end"
        private const val KEY_MODE = "range_mode"
    }

    // ---- state -------------------------------------------------------------
    private var selectedVideo: Uri? = null
    private var durationMs = 0L
    private var selectedStartMs = 0L
    private var selectedEndMs = 0L
    private var mode = TimelineView.Mode.KEEP
    private var exporting = false

    private var player: ExoPlayer? = null
    private var transformer: Transformer? = null
    private var exportFile: File? = null
    private var lastSavedUri: Uri? = null
    private var adView: AdView? = null

    @Volatile
    private var loadToken = 0

    private val ui = Handler(Looper.getMainLooper())
    private val thumbExecutor = Executors.newSingleThreadExecutor()
    private val saveExecutor = Executors.newSingleThreadExecutor()

    // ---- views -------------------------------------------------------------
    private lateinit var root: View
    private lateinit var statusText: TextView
    private lateinit var btnChange: MaterialButton
    private lateinit var btnChoose: MaterialButton
    private lateinit var emptyState: View
    private lateinit var playerView: PlayerView
    private lateinit var btnPlay: ImageButton
    private lateinit var timeText: TextView
    private lateinit var modeToggle: MaterialButtonToggleGroup
    private lateinit var btnModeKeep: MaterialButton
    private lateinit var btnModeRemove: MaterialButton
    private lateinit var modeHint: TextView
    private lateinit var timeline: TimelineView
    private lateinit var inText: TextView
    private lateinit var outText: TextView
    private lateinit var btnSetIn: MaterialButton
    private lateinit var btnSetOut: MaterialButton
    private lateinit var summaryText: TextView
    private lateinit var qualityGroup: ChipGroup
    private lateinit var exportBar: View
    private lateinit var resultGroup: View
    private lateinit var btnShare: MaterialButton
    private lateinit var btnPlayResult: MaterialButton
    private lateinit var btnExport: MaterialButton
    private lateinit var progressGroup: View
    private lateinit var progressText: TextView
    private lateinit var progressBar: LinearProgressIndicator
    private lateinit var btnCancel: MaterialButton
    private lateinit var bannerContainer: FrameLayout

    // ---- activity result launchers ----------------------------------------
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startExport() else showMessage(getString(R.string.msg_permission_needed))
        }

    // ---- periodic tickers --------------------------------------------------
    private val ticker = object : Runnable {
        override fun run() {
            val p = player ?: return
            enforcePlaybackRange(p)
            syncPlayhead()
            if (p.isPlaying) ui.postDelayed(this, 40L)
        }
    }

    private val progressTicker = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val holder = ProgressHolder()
            if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                updateExportProgress(holder.progress)
            }
            ui.postDelayed(this, 250L)
        }
    }

    // ======================================================================
    // Lifecycle
    // ======================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        // Edge-to-edge is mandatory on Android 15 (targetSdk 35); opt in everywhere so
        // the layout behaves the same on every version.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        bindViews()
        applyInsets()
        setupListeners()
        setupAds()
        setMode(TimelineView.Mode.KEEP)
        refreshEnabledState()

        if (savedInstanceState != null) {
            val saved = savedInstanceState.getString(KEY_URI)
            if (saved != null) {
                val modeIndex = savedInstanceState.getInt(KEY_MODE, 0)
                loadVideo(
                    Uri.parse(saved),
                    savedInstanceState.getLong(KEY_START, 0L),
                    savedInstanceState.getLong(KEY_END, Long.MAX_VALUE),
                    TimelineView.Mode.values().getOrElse(modeIndex) { TimelineView.Mode.KEEP }
                )
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        selectedVideo?.let {
            outState.putString(KEY_URI, it.toString())
            outState.putLong(KEY_START, selectedStartMs)
            outState.putLong(KEY_END, selectedEndMs)
            outState.putInt(KEY_MODE, mode.ordinal)
        }
    }

    override fun onResume() {
        super.onResume()
        adView?.resume()
    }

    override fun onPause() {
        adView?.pause()
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        if (transformer != null) {
            transformer?.cancel()
            transformer = null
            exportFile?.delete()
        }
        playerView.player = null
        player?.release()
        player = null
        adView?.destroy()
        thumbExecutor.shutdownNow()
        saveExecutor.shutdown()
        super.onDestroy()
    }

    // ======================================================================
    // Setup
    // ======================================================================
    private fun bindViews() {
        root = findViewById(R.id.root)
        statusText = findViewById(R.id.statusText)
        btnChange = findViewById(R.id.btnChange)
        btnChoose = findViewById(R.id.btnChoose)
        emptyState = findViewById(R.id.emptyState)
        playerView = findViewById(R.id.playerView)
        btnPlay = findViewById(R.id.btnPlay)
        timeText = findViewById(R.id.timeText)
        modeToggle = findViewById(R.id.modeToggle)
        btnModeKeep = findViewById(R.id.btnModeKeep)
        btnModeRemove = findViewById(R.id.btnModeRemove)
        modeHint = findViewById(R.id.modeHint)
        timeline = findViewById(R.id.timeline)
        inText = findViewById(R.id.inText)
        outText = findViewById(R.id.outText)
        btnSetIn = findViewById(R.id.btnSetIn)
        btnSetOut = findViewById(R.id.btnSetOut)
        summaryText = findViewById(R.id.summaryText)
        qualityGroup = findViewById(R.id.qualityGroup)
        exportBar = findViewById(R.id.exportBar)
        resultGroup = findViewById(R.id.resultGroup)
        btnShare = findViewById(R.id.btnShare)
        btnPlayResult = findViewById(R.id.btnPlayResult)
        btnExport = findViewById(R.id.btnExport)
        progressGroup = findViewById(R.id.progressGroup)
        progressText = findViewById(R.id.progressText)
        progressBar = findViewById(R.id.progressBar)
        btnCancel = findViewById(R.id.btnCancel)
        bannerContainer = findViewById(R.id.bannerContainer)
    }

    private fun applyInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            // top/left/right on the root; bottom on the banner strip so the dark bar
            // continues behind the navigation bar instead of leaving a seam
            root.setPadding(bars.left, bars.top, bars.right, 0)
            bannerContainer.setPadding(0, 0, 0, bars.bottom)
            insets
        }
    }

    private fun setupListeners() {
        btnChoose.setOnClickListener { openPicker() }
        btnChange.setOnClickListener { openPicker() }
        btnPlay.setOnClickListener { togglePlayback() }
        playerView.setOnClickListener { if (selectedVideo != null && !exporting) togglePlayback() }

        modeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                setMode(
                    if (checkedId == R.id.btnModeRemove) TimelineView.Mode.REMOVE
                    else TimelineView.Mode.KEEP
                )
            }
        }

        btnSetIn.setOnClickListener { setInFromPlayhead() }
        btnSetOut.setOnClickListener { setOutFromPlayhead() }

        timeline.onRangeChanged = { start, end, handle ->
            selectedStartMs = start
            selectedEndMs = end
            updateSummary()
            seekPreview(if (handle == TimelineView.Handle.START) start else end)
        }
        timeline.onScrub = { position -> seekPreview(position) }
        timeline.onDragStateChanged = { dragging ->
            player?.setSeekParameters(
                if (dragging) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT
            )
            if (dragging) player?.pause()
        }

        qualityGroup.setOnCheckedStateChangeListener { _, _ -> hideResult() }

        btnExport.setOnClickListener { requestExport() }
        btnCancel.setOnClickListener { cancelExport() }
        btnShare.setOnClickListener { shareResult() }
        btnPlayResult.setOnClickListener { openResult() }
    }

    private fun setupAds() {
        try {
            MobileAds.initialize(this)
            val view = AdView(this).apply {
                adUnitId = "ca-app-pub-3940256099942544/6300978111" // Google test banner unit
                setAdSize(AdSize.BANNER)
                loadAd(AdRequest.Builder().build())
            }
            adView = view
            bannerContainer.addView(
                view,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER_HORIZONTAL
                )
            )
        } catch (_: Exception) {
            // The editor works fine without ads.
        }
    }

    // ======================================================================
    // Loading a video
    // ======================================================================
    private fun openPicker() {
        if (exporting) return
        picker.launch(arrayOf("video/*"))
    }

    private fun loadVideo(
        uri: Uri,
        restoreStart: Long? = null,
        restoreEnd: Long? = null,
        restoreMode: TimelineView.Mode? = null
    ) {
        val duration = readDuration(uri)
        if (duration <= 0L) {
            showMessage(getString(R.string.msg_load_failed))
            return
        }
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            // Not every provider allows persistable permissions; that's fine.
        }

        val token = ++loadToken
        selectedVideo = uri
        durationMs = duration
        selectedStartMs = (restoreStart ?: 0L).coerceIn(0L, duration)
        selectedEndMs = (restoreEnd ?: duration).coerceIn(selectedStartMs, duration)
        if (selectedEndMs - selectedStartMs < TimelineView.MIN_GAP_MS) {
            selectedStartMs = 0L
            selectedEndMs = duration
        }

        emptyState.visibility = View.GONE
        btnChange.visibility = View.VISIBLE

        timeline.setTimeline(duration, THUMB_COUNT)
        timeline.setRange(selectedStartMs, selectedEndMs)

        val newMode = restoreMode ?: TimelineView.Mode.KEEP
        modeToggle.check(if (newMode == TimelineView.Mode.REMOVE) R.id.btnModeRemove else R.id.btnModeKeep)
        setMode(newMode)

        setStatus(getString(R.string.status_ready, formatTime(duration)))
        createPlayer(uri)
        updateTimeLabel(0L)
        refreshEnabledState()
        loadThumbnails(uri, duration, token)
    }

    private fun createPlayer(uri: Uri) {
        ui.removeCallbacks(ticker)
        player?.release()
        player = ExoPlayer.Builder(this).build().also { p ->
            playerView.player = p
            p.setMediaItem(MediaItem.fromUri(uri))
            p.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                    btnPlay.contentDescription =
                        getString(if (isPlaying) R.string.cd_pause else R.string.cd_play)
                    if (isPlaying) {
                        ui.post(ticker)
                    } else {
                        ui.removeCallbacks(ticker)
                        syncPlayhead()
                    }
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_ENDED) {
                        player?.seekTo(if (mode == TimelineView.Mode.KEEP) selectedStartMs else 0L)
                        syncPlayhead()
                    }
                }
            })
            p.prepare()
            p.playWhenReady = false
        }
    }

    private fun loadThumbnails(uri: Uri, duration: Long, token: Int) {
        thumbExecutor.execute {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, uri)
                for (i in 0 until THUMB_COUNT) {
                    if (token != loadToken) break
                    // sample the middle of each cell so the strip represents the whole clip
                    val timeUs = (duration * (2 * i + 1) / (2 * THUMB_COUNT)) * 1000L
                    val frame = retriever.getFrameAtTime(
                        timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                    ) ?: continue
                    val thumb = scaleToHeight(frame, THUMB_HEIGHT_PX)
                    runOnUiThread {
                        if (token == loadToken) timeline.setFrame(i, thumb)
                    }
                }
            } catch (_: Exception) {
                // A blank strip is still fully usable.
            } finally {
                try { retriever.release() } catch (_: Exception) {}
            }
        }
    }

    /** Full-resolution frames are huge (≈33 MB for 4K), so shrink immediately. */
    private fun scaleToHeight(src: Bitmap, height: Int): Bitmap {
        if (src.height <= height) return src
        val width = (src.width.toFloat() * height / src.height).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(src, width, height, true)
        if (scaled !== src) src.recycle()
        return scaled
    }

    private fun readDuration(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    // ======================================================================
    // Mode, range and summary
    // ======================================================================
    private fun setMode(newMode: TimelineView.Mode) {
        mode = newMode
        timeline.setMode(newMode)
        val keep = newMode == TimelineView.Mode.KEEP
        modeHint.setText(if (keep) R.string.hint_keep else R.string.hint_remove)
        btnExport.setText(if (keep) R.string.export_keep else R.string.export_remove)
        updateSummary()
    }

    private fun updateSummary() {
        inText.text = formatTime(selectedStartMs, tenths = true)
        outText.text = formatTime(selectedEndMs, tenths = true)
        val selected = (selectedEndMs - selectedStartMs).coerceAtLeast(0L)
        summaryText.text = if (mode == TimelineView.Mode.KEEP) {
            getString(R.string.summary_keep, formatTime(selected), formatTime(durationMs))
        } else {
            getString(
                R.string.summary_remove,
                formatTime((durationMs - selected).coerceAtLeast(0L)),
                formatTime(selected)
            )
        }
        hideResult()
    }

    private fun setInFromPlayhead() {
        val position = (player?.currentPosition ?: return).coerceIn(0L, durationMs)
        if (position > selectedEndMs - TimelineView.MIN_GAP_MS) {
            showMessage(getString(R.string.msg_in_before_out))
            return
        }
        selectedStartMs = position
        timeline.setRange(selectedStartMs, selectedEndMs)
        updateSummary()
    }

    private fun setOutFromPlayhead() {
        val position = (player?.currentPosition ?: return).coerceIn(0L, durationMs)
        if (position < selectedStartMs + TimelineView.MIN_GAP_MS) {
            showMessage(getString(R.string.msg_out_after_in))
            return
        }
        selectedEndMs = position
        timeline.setRange(selectedStartMs, selectedEndMs)
        updateSummary()
    }

    // ======================================================================
    // Playback
    // ======================================================================
    private fun togglePlayback() {
        val p = player ?: return
        if (p.isPlaying) {
            p.pause()
            return
        }
        val position = p.currentPosition
        if (mode == TimelineView.Mode.KEEP) {
            if (position < selectedStartMs || position >= selectedEndMs) p.seekTo(selectedStartMs)
        } else if (position >= selectedStartMs && position < selectedEndMs) {
            p.seekTo(if (selectedEndMs >= durationMs - END_EPSILON_MS) 0L else selectedEndMs)
        }
        p.play()
    }

    /**
     * Makes the preview match the export: in KEEP mode playback stops at OUT,
     * in REMOVE mode it jumps over the section that will be cut.
     */
    private fun enforcePlaybackRange(p: ExoPlayer) {
        val position = p.currentPosition
        if (mode == TimelineView.Mode.KEEP) {
            if (position >= selectedEndMs) {
                p.pause()
                p.seekTo(selectedStartMs)
            }
        } else if (position >= selectedStartMs && position < selectedEndMs) {
            if (selectedEndMs >= durationMs - END_EPSILON_MS) {
                p.pause()
                p.seekTo(0L)
            } else {
                p.seekTo(selectedEndMs)
            }
        }
    }

    private fun seekPreview(positionMs: Long) {
        player?.seekTo(positionMs)
        timeline.setPlayhead(positionMs)
        updateTimeLabel(positionMs)
    }

    private fun syncPlayhead() {
        val position = player?.currentPosition ?: return
        timeline.setPlayhead(position)
        updateTimeLabel(position)
    }

    private fun updateTimeLabel(positionMs: Long) {
        timeText.text = "${formatTime(positionMs)} / ${formatTime(durationMs)}"
    }

    // ======================================================================
    // Export
    // ======================================================================
    private fun requestExport() {
        // Android 9 and below need the legacy storage permission to write into Movies/.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        startExport()
    }

    private fun startExport() {
        val uri = selectedVideo ?: return
        if (exporting) return
        if (durationMs <= 0L || selectedEndMs <= selectedStartMs) {
            showMessage(getString(R.string.msg_invalid_range))
            return
        }

        val height = selectedOutputHeight()
        val parts = mutableListOf<EditedMediaItem>()
        if (mode == TimelineView.Mode.REMOVE) {
            if (selectedStartMs >= MIN_PART_MS) {
                parts.add(clipped(uri, 0L, selectedStartMs, height))
            }
            if (durationMs - selectedEndMs >= MIN_PART_MS) {
                parts.add(clipped(uri, selectedEndMs, durationMs, height))
            }
            if (parts.isEmpty()) {
                showMessage(getString(R.string.msg_nothing_left))
                return
            }
        } else {
            parts.add(clipped(uri, selectedStartMs, selectedEndMs, height))
        }

        player?.pause()
        hideResult()
        setExporting(true)
        try {
            val edited = Composition.Builder(EditedMediaItemSequence(parts)).build()
            val output = File(cacheDir, "trim_${System.currentTimeMillis()}.mp4")
            exportFile = output
            val t = Transformer.Builder(this).addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    transformer = null
                    ui.removeCallbacks(progressTicker)
                    updateExportProgress(100)
                    btnCancel.visibility = View.INVISIBLE
                    progressText.setText(R.string.progress_saving)
                    saveExecutor.execute { saveToGallery(output) }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    transformer = null
                    ui.removeCallbacks(progressTicker)
                    output.delete()
                    setExporting(false)
                    showMessage(
                        getString(
                            R.string.msg_export_failed,
                            exportException.message ?: getString(R.string.msg_export_failed_generic)
                        )
                    )
                }
            }).build()
            transformer = t
            t.start(edited, output.absolutePath)
            ui.post(progressTicker)
        } catch (e: Exception) {
            transformer = null
            exportFile?.delete()
            setExporting(false)
            showMessage(getString(R.string.msg_export_failed, e.message ?: ""))
        }
    }

    private fun cancelExport() {
        transformer?.cancel()
        transformer = null
        ui.removeCallbacks(progressTicker)
        exportFile?.delete()
        setExporting(false)
        showMessage(getString(R.string.msg_export_cancelled))
    }

    private fun selectedOutputHeight(): Int? = when (qualityGroup.checkedChipId) {
        R.id.chip1080 -> 1080
        R.id.chip720 -> 720
        R.id.chip480 -> 480
        else -> null
    }

    private fun clipped(uri: Uri, from: Long, to: Long, outputHeight: Int?): EditedMediaItem {
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(from).setEndPositionMs(to).build()
        ).build()
        val builder = EditedMediaItem.Builder(item)
        if (outputHeight != null) {
            val presentation = Presentation.createForHeight(outputHeight)
            builder.setEffects(Effects(emptyList<AudioProcessor>(), listOf<Effect>(presentation)))
        }
        return builder.build()
    }

    /** Runs on [saveExecutor]; never touches views directly. */
    private fun saveToGallery(file: File) {
        try {
            val name = "VideoTrim_${System.currentTimeMillis()}.mp4"
            val dest: Uri
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoTrim Pro")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Gallery destination unavailable")
                contentResolver.openOutputStream(dest)?.use { out ->
                    file.inputStream().use { it.copyTo(out) }
                } ?: error("Could not write output")
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(dest, values, null, null)
            } else {
                // Android 9 and below: RELATIVE_PATH / IS_PENDING don't exist, so copy the
                // file into Movies/VideoTrim Pro ourselves and register it with MediaStore.
                @Suppress("DEPRECATION")
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "VideoTrim Pro"
                )
                if (!dir.exists() && !dir.mkdirs()) error("Could not create folder")
                val target = File(dir, name)
                file.inputStream().use { input ->
                    target.outputStream().use { out -> input.copyTo(out) }
                }
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.DATA, target.absolutePath)
                }
                dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Gallery destination unavailable")
            }
            file.delete()
            runOnUiThread {
                lastSavedUri = dest
                setExporting(false)
                setStatus(getString(R.string.status_saved))
                resultGroup.visibility = View.VISIBLE
            }
        } catch (e: Exception) {
            file.delete()
            runOnUiThread {
                setExporting(false)
                showMessage(getString(R.string.msg_save_failed, e.message ?: ""))
            }
        }
    }

    private fun shareResult() {
        val uri = lastSavedUri ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(null, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, getString(R.string.share_title)))
    }

    private fun openResult() {
        val uri = lastSavedUri ?: return
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "video/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(view)
        } catch (_: ActivityNotFoundException) {
            showMessage(getString(R.string.msg_no_player_app))
        }
    }

    // ======================================================================
    // UI helpers
    // ======================================================================
    private fun setExporting(value: Boolean) {
        exporting = value
        progressGroup.visibility = if (value) View.VISIBLE else View.GONE
        btnExport.visibility = if (value) View.GONE else View.VISIBLE
        if (value) {
            btnCancel.visibility = View.VISIBLE
            progressBar.setProgressCompat(0, false)
            progressText.setText(R.string.progress_preparing)
            setStatus(getString(R.string.progress_preparing))
        }
        refreshEnabledState()
    }

    private fun updateExportProgress(percent: Int) {
        val clamped = percent.coerceIn(0, 100)
        progressBar.setProgressCompat(clamped, true)
        progressText.text = getString(R.string.progress_percent, clamped)
    }

    private fun refreshEnabledState() {
        val hasVideo = selectedVideo != null
        val canEdit = hasVideo && !exporting
        listOf<View>(btnPlay, btnSetIn, btnSetOut, btnExport, btnModeKeep, btnModeRemove)
            .forEach { it.isEnabled = canEdit }
        btnPlay.alpha = if (canEdit) 1f else 0.4f
        timeline.isEnabled = canEdit
        btnChange.isEnabled = !exporting
        btnChoose.isEnabled = !exporting
        for (i in 0 until qualityGroup.childCount) {
            qualityGroup.getChildAt(i).isEnabled = !exporting
        }
    }

    private fun hideResult() {
        resultGroup.visibility = View.GONE
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun showMessage(message: String) {
        Snackbar.make(root, message, Snackbar.LENGTH_LONG).setAnchorView(exportBar).show()
    }

    private fun formatTime(ms: Long, tenths: Boolean = false): String {
        val clamped = ms.coerceAtLeast(0L)
        val totalSeconds = clamped / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        val base = if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
        return if (tenths) base + "." + ((clamped % 1000) / 100) else base
    }
}
