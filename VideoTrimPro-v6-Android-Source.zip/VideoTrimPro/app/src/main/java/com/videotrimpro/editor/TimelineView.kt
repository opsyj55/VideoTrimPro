package com.videotrimpro.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.min

/**
 * Thumbnail timeline with:
 *  - two trim handles (IN / OUT) that can be dragged without "jumping" to the finger
 *  - a playhead that can be scrubbed by touching anywhere that isn't a handle
 *  - two display modes: KEEP (dim everything outside the handles) and
 *    REMOVE (tint the area between the handles red, because it will be cut out)
 *
 * Thumbnails are supplied one at a time by MainActivity (see [setFrame]) so the strip
 * fills in progressively while the video is analysed on a background thread.
 */
class TimelineView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { KEEP, REMOVE }
    enum class Handle { START, END }

    companion object {
        /** Smallest allowed distance between IN and OUT. */
        const val MIN_GAP_MS = 300L
    }

    /** Called while a handle is dragged. */
    var onRangeChanged: ((startMs: Long, endMs: Long, handle: Handle) -> Unit)? = null
    /** Called while the playhead is scrubbed. */
    var onScrub: ((positionMs: Long) -> Unit)? = null
    /** true when a finger goes down on the timeline, false when it lifts. */
    var onDragStateChanged: ((dragging: Boolean) -> Unit)? = null

    var startMs = 0L
        private set
    var endMs = 1L
        private set

    private var durationMs = 1L
    private var playheadMs = 0L
    private var mode = Mode.KEEP
    private var hasMedia = false
    private var frames: Array<Bitmap?> = emptyArray()

    private var activeHandle: Handle? = null
    private var scrubbing = false
    private var touchOffsetPx = 0f

    // ---- paints / geometry -------------------------------------------------
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val colorPlaceholder = ContextCompat.getColor(context, R.color.vtp_surface_high)
    private val colorPrimary = ContextCompat.getColor(context, R.color.vtp_primary)
    private val colorDanger = ContextCompat.getColor(context, R.color.vtp_danger)

    private val handleW = dp(14f)
    private val stripPath = Path()
    private val stripRect = RectF()
    private val srcRect = Rect()
    private val dstRect = RectF()
    private val tmpRect = RectF()

    private var trackLeft = 0f
    private var trackRight = 0f
    private var stripTop = 0f
    private var stripBottom = 0f

    // ---- public API --------------------------------------------------------
    fun setTimeline(duration: Long, frameCount: Int) {
        durationMs = duration.coerceAtLeast(1L)
        startMs = 0L
        endMs = durationMs
        playheadMs = 0L
        frames = arrayOfNulls(frameCount.coerceAtLeast(1))
        hasMedia = true
        invalidate()
    }

    fun setFrame(index: Int, bitmap: Bitmap) {
        if (index in frames.indices) {
            frames[index] = bitmap
            invalidate()
        }
    }

    fun setRange(start: Long, end: Long) {
        startMs = start.coerceIn(0L, durationMs)
        endMs = end.coerceIn(startMs, durationMs)
        invalidate()
    }

    fun setPlayhead(positionMs: Long) {
        playheadMs = positionMs.coerceIn(0L, durationMs)
        invalidate()
    }

    fun setMode(newMode: Mode) {
        mode = newMode
        invalidate()
    }

    // ---- layout ------------------------------------------------------------
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        trackLeft = handleW
        trackRight = w - handleW
        stripTop = dp(12f)
        stripBottom = h - dp(12f)
        stripRect.set(trackLeft, stripTop, trackRight, stripBottom)
        stripPath.reset()
        stripPath.addRoundRect(stripRect, dp(8f), dp(8f), Path.Direction.CW)
    }

    private fun timeToX(ms: Long): Float =
        trackLeft + (ms.toFloat() / durationMs) * (trackRight - trackLeft)

    private fun xToTime(x: Float): Long {
        val span = (trackRight - trackLeft).coerceAtLeast(1f)
        val fraction = ((x - trackLeft) / span).coerceIn(0f, 1f)
        return (fraction * durationMs).toLong()
    }

    private fun minGap(): Long = min(MIN_GAP_MS, durationMs / 2)

    // ---- drawing -----------------------------------------------------------
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        // Strip background + thumbnails, clipped to rounded corners
        canvas.save()
        canvas.clipPath(stripPath)
        fillPaint.color = colorPlaceholder
        canvas.drawRect(stripRect, fillPaint)

        if (hasMedia && frames.isNotEmpty()) {
            val cellW = (trackRight - trackLeft) / frames.size
            frames.forEachIndexed { i, bmp ->
                if (bmp != null) {
                    dstRect.set(
                        trackLeft + i * cellW, stripTop,
                        trackLeft + (i + 1) * cellW + 1f, stripBottom
                    )
                    drawCenterCrop(canvas, bmp, dstRect)
                }
            }
        }

        if (!hasMedia) {
            canvas.restore()
            return
        }

        val sx = timeToX(startMs)
        val ex = timeToX(endMs)

        if (mode == Mode.KEEP) {
            // dim what will be thrown away (outside the handles)
            fillPaint.color = 0xB3101018.toInt()
            tmpRect.set(trackLeft, stripTop, sx, stripBottom)
            canvas.drawRect(tmpRect, fillPaint)
            tmpRect.set(ex, stripTop, trackRight, stripBottom)
            canvas.drawRect(tmpRect, fillPaint)
        } else {
            // tint what will be thrown away (between the handles)
            fillPaint.color = 0x99EF4444.toInt()
            tmpRect.set(sx, stripTop, ex, stripBottom)
            canvas.drawRect(tmpRect, fillPaint)
        }
        canvas.restore()

        val accent = if (mode == Mode.KEEP) colorPrimary else colorDanger

        // top & bottom borders of the selection
        strokePaint.color = accent
        strokePaint.strokeWidth = dp(3f)
        val half = strokePaint.strokeWidth / 2f
        canvas.drawLine(sx, stripTop + half, ex, stripTop + half, strokePaint)
        canvas.drawLine(sx, stripBottom - half, ex, stripBottom - half, strokePaint)

        // handles sit just outside the selection so they never cover the picture
        fillPaint.color = accent
        tmpRect.set(sx - handleW, stripTop, sx, stripBottom)
        canvas.drawRoundRect(tmpRect, dp(5f), dp(5f), fillPaint)
        drawGrip(canvas, tmpRect.centerX(), (stripTop + stripBottom) / 2f)

        tmpRect.set(ex, stripTop, ex + handleW, stripBottom)
        canvas.drawRoundRect(tmpRect, dp(5f), dp(5f), fillPaint)
        drawGrip(canvas, tmpRect.centerX(), (stripTop + stripBottom) / 2f)

        // playhead
        val px = timeToX(playheadMs)
        strokePaint.color = 0xFFFFFFFF.toInt()
        strokePaint.strokeWidth = dp(2f)
        canvas.drawLine(px, dp(4f), px, height - dp(4f), strokePaint)
        fillPaint.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(px, dp(5f), dp(5f), fillPaint)
    }

    private fun drawGrip(canvas: Canvas, cx: Float, cy: Float) {
        strokePaint.color = 0xCCFFFFFF.toInt()
        strokePaint.strokeWidth = dp(1.5f)
        val gap = dp(2.5f)
        val halfLen = dp(8f)
        canvas.drawLine(cx - gap, cy - halfLen, cx - gap, cy + halfLen, strokePaint)
        canvas.drawLine(cx + gap, cy - halfLen, cx + gap, cy + halfLen, strokePaint)
    }

    /** Draws [bmp] so it fills [dst] without distortion (centre-crop). */
    private fun drawCenterCrop(canvas: Canvas, bmp: Bitmap, dst: RectF) {
        val dstRatio = dst.width() / dst.height()
        val srcRatio = bmp.width.toFloat() / bmp.height
        if (srcRatio > dstRatio) {
            val newW = (bmp.height * dstRatio).toInt().coerceAtLeast(1)
            val left = (bmp.width - newW) / 2
            srcRect.set(left, 0, left + newW, bmp.height)
        } else {
            val newH = (bmp.width / dstRatio).toInt().coerceAtLeast(1)
            val top = (bmp.height - newH) / 2
            srcRect.set(0, top, bmp.width, top + newH)
        }
        canvas.drawBitmap(bmp, srcRect, dst, bitmapPaint)
    }

    // ---- touch -------------------------------------------------------------
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled || !hasMedia) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val sx = timeToX(startMs)
                val ex = timeToX(endMs)
                val distStart = abs(event.x - (sx - handleW / 2f))
                val distEnd = abs(event.x - (ex + handleW / 2f))
                val slop = dp(28f)
                activeHandle = when {
                    distStart <= slop && distStart <= distEnd -> Handle.START
                    distEnd <= slop -> Handle.END
                    else -> null
                }
                when (activeHandle) {
                    Handle.START -> touchOffsetPx = event.x - sx
                    Handle.END -> touchOffsetPx = event.x - ex
                    null -> {
                        scrubbing = true
                        scrubTo(event.x)
                    }
                }
                parent?.requestDisallowInterceptTouchEvent(true)
                onDragStateChanged?.invoke(true)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val handle = activeHandle
                if (handle != null) {
                    val t = xToTime(event.x - touchOffsetPx)
                    if (handle == Handle.START) {
                        startMs = t.coerceIn(0L, (endMs - minGap()).coerceAtLeast(0L))
                    } else {
                        endMs = t.coerceIn((startMs + minGap()).coerceAtMost(durationMs), durationMs)
                    }
                    invalidate()
                    onRangeChanged?.invoke(startMs, endMs, handle)
                } else if (scrubbing) {
                    scrubTo(event.x)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val wasActive = activeHandle != null || scrubbing
                activeHandle = null
                scrubbing = false
                parent?.requestDisallowInterceptTouchEvent(false)
                if (wasActive) onDragStateChanged?.invoke(false)
                if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
                return true
            }
        }
        return true
    }

    private fun scrubTo(x: Float) {
        playheadMs = xToTime(x)
        invalidate()
        onScrub?.invoke(playheadMs)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}
